package com.example.mvvmfgd.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.mvvmfgd.R
import com.example.mvvmfgd.databinding.FragmentInputBinding
import com.example.mvvmfgd.model.AttendanceModel
import com.example.mvvmfgd.viewmodel.AttendanceViewModel

class InputFragment : Fragment() {
    private var _binding: FragmentInputBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AttendanceViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInputBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupCategoryDropdown()
        setupSaveButton()
    }

    private fun setupCategoryDropdown() {
        val categories = arrayOf("Student", "Professional", "Expert")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, categories)
        binding.categoryInput.setAdapter(adapter)
    }

    private fun setupSaveButton() {
        binding.saveButton.setOnClickListener {
            val name = binding.nameInput.text.toString()
            val phone = binding.phoneInput.text.toString()
            val email = binding.emailInput.text.toString()
            val gender = when {
                binding.maleRadio.isChecked -> "Male"
                binding.femaleRadio.isChecked -> "Female"
                else -> ""
            }
            
            val skillSet = mutableListOf<String>().apply {
                if (binding.androidCheckbox.isChecked) add("Android Development")
                if (binding.webCheckbox.isChecked) add("Web Development")
                if (binding.iosCheckbox.isChecked) add("iOS Development")
            }
            
            val category = binding.categoryInput.text.toString()

            val attendanceData = AttendanceModel(
                name = name,
                phoneNumber = phone,
                email = email,
                gender = gender,
                skillSet = skillSet,
                participantCategory = category
            )

            viewModel.saveAttendanceData(attendanceData)
            findNavController().navigate(R.id.action_inputFragment_to_outputFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 