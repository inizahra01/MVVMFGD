package com.example.mvvmfgd.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.mvvmfgd.model.AttendanceModel

class AttendanceViewModel : ViewModel() {
    private val _attendanceData = MutableLiveData<AttendanceModel>()
    val attendanceData: LiveData<AttendanceModel> = _attendanceData

    fun saveAttendanceData(attendance: AttendanceModel) {
        _attendanceData.value = attendance
    }
} 