package com.example.mvvmfgd.model

data class AttendanceModel(
    val name: String,
    val phoneNumber: String,
    val email: String,
    val gender: String,
    val skillSet: List<String>,
    val participantCategory: String
) 