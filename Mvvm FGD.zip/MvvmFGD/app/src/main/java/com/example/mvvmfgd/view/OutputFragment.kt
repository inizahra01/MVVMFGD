package com.example.mvvmfgd.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.mvvmfgd.databinding.FragmentOutputBinding
import com.example.mvvmfgd.viewmodel.AttendanceViewModel

class OutputFragment : Fragment() {
    private var _binding: FragmentOutputBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AttendanceViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentOutputBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupBackButton()
        observeAttendanceData()
    }

    private fun setupBackButton() {
        binding.backButton.setOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun observeAttendanceData() {
        viewModel.attendanceData.observe(viewLifecycleOwner) { attendance ->
            binding.apply {
                nameOutput.text = attendance.name
                phoneOutput.text = attendance.phoneNumber
                emailOutput.text = attendance.email
                genderOutput.text = attendance.gender
                skillSetOutput.text = attendance.skillSet.joinToString(", ")
                categoryOutput.text = attendance.participantCategory
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 